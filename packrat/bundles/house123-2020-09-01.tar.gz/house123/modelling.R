linear.model<-lm(price~bedroom+bathroom+carport+buildingarea+landarea,data = house123)
summary(linear.model)
